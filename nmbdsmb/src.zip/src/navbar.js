import React, { Component } from 'react';

class Navbar  extends Component {
    state = {  }
    render() { 
        return (<nav className='navbar bg-dark'>
            <a href='#' className='Navbar-brand text-white'>Sample App</a>
        </nav>);
    }
}
 
export default Navbar ;