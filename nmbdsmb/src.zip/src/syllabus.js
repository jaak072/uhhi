import React, { Component } from 'react';

class Syllabus extends Component {
    state = {  }
    render() { 
        return (  
            <div>
                <div className='row'>
                    <div className='col-md-3 col-lg-3 col-xl-3'></div>
                </div>
            </div>
        );
    }
}
 
export default Syllabus;